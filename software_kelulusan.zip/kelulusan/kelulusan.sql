-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 29, 2020 at 10:25 AM
-- Server version: 5.7.29-0ubuntu0.18.04.1
-- PHP Version: 7.2.24-0ubuntu0.18.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kelulusan`
--

-- --------------------------------------------------------

--
-- Table structure for table `mapel`
--

CREATE TABLE `mapel` (
  `mapel_id` int(11) NOT NULL,
  `mapel_nama` varchar(100) NOT NULL,
  `mapel_kode` varchar(10) NOT NULL,
  `mapel_kelompok` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mapel`
--

INSERT INTO `mapel` (`mapel_id`, `mapel_nama`, `mapel_kode`, `mapel_kelompok`) VALUES
(1, 'Pendidikan Agama dan Budi Pekerti', 'pab', 'A'),
(2, 'Pendidikan Kewarganegaraan', 'pkn', 'A'),
(3, 'Bahasa Indonesia', 'ind', 'A'),
(4, 'Bahasa Inggris', 'ing', 'A'),
(6, 'Matematika', 'mtkw', 'A'),
(7, 'Sejarah Indonesia', 'sji', 'A'),
(8, 'Pendidikan Jasmani dan Kesehatan', 'pjk', 'B'),
(9, 'Seni Budaya', 'snb', 'B'),
(10, 'Prakarya dan Kewirausahaan', 'pkwu', 'B'),
(11, 'Bahasa Jawa', 'bjw', 'B'),
(12, 'Matematika', 'mtklm', 'C'),
(13, 'Fisika', 'fis', 'C'),
(14, 'Kimia', 'kim', 'C'),
(15, 'Biologi', 'bio', 'C'),
(16, 'Sejarah', 'sjlm', 'C'),
(17, 'Geografi', 'geo', 'C'),
(18, 'Sosiologi', 'sos', 'C'),
(19, 'Ekonomi', 'eko', 'C'),
(20, 'Bahasa dan Sastra Inggris', 'bsig', 'C'),
(21, 'Bahasa Arab', 'arb', 'C'),
(22, 'Bahasa Jepang', 'jpg', 'C'),
(23, 'Bahasa Jerman', 'jrm', 'C'),
(24, 'Bahasa Mandarin', 'mdr', 'C');

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `nilai_id` int(11) NOT NULL,
  `nilai_siswa_nis` varchar(11) NOT NULL,
  `nilai_mapel_id` int(11) NOT NULL,
  `nilai_angka` int(11) NOT NULL,
  `nilai_tahun` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`nilai_id`, `nilai_siswa_nis`, `nilai_mapel_id`, `nilai_angka`, `nilai_tahun`) VALUES
(1, '12345', 8, 98, '2020'),
(2, '12346', 8, 75, '2020'),
(3, '12347', 8, 85, '2020'),
(4, '12348', 8, 94, '2020'),
(5, '12349', 8, 65, '2020'),
(6, '12350', 8, 85, '2020'),
(7, '12351', 8, 52, '2020'),
(8, '12352', 8, 55, '2020'),
(9, '12353', 8, 85, '2020'),
(10, '12345', 2, 78, '2020'),
(11, '12346', 2, 80, '2020'),
(12, '12347', 2, 82, '2020'),
(13, '12348', 2, 84, '2020'),
(14, '12349', 2, 86, '2020'),
(15, '12350', 2, 88, '2020'),
(16, '12351', 2, 90, '2020'),
(17, '12352', 2, 92, '2020'),
(18, '12353', 2, 94, '2020'),
(19, '12345', 3, 98, '2020'),
(20, '12346', 3, 96, '2020'),
(21, '12347', 3, 78, '2020'),
(22, '12348', 3, 88, '2020'),
(23, '12349', 3, 95, '2020'),
(24, '12350', 3, 65, '2020'),
(25, '12351', 3, 88, '2020'),
(26, '12352', 3, 67, '2020'),
(27, '12353', 3, 88, '2020'),
(28, '12345', 12, 87, '2020'),
(29, '12346', 12, 85, '2020'),
(30, '12347', 12, 62, '2020'),
(31, '12348', 12, 85, '2020'),
(32, '12349', 12, 88, '2020'),
(33, '12350', 12, 65, '2020'),
(34, '12351', 12, 54, '2020'),
(35, '12352', 12, 75, '2020'),
(36, '12353', 12, 66, '2020'),
(37, '98756', 2, 79, '2020'),
(38, '87546', 2, 81, '2020'),
(39, '54652', 2, 83, '2020'),
(40, '87543', 2, 85, '2020'),
(41, '89754', 2, 87, '2020'),
(42, '88754', 2, 89, '2020'),
(43, '84576', 2, 91, '2020'),
(44, '98754', 2, 93, '2020'),
(45, '23546', 2, 95, '2020');

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan`
--

CREATE TABLE `pengaturan` (
  `pengaturan_id` int(1) NOT NULL,
  `pengaturan_sekolah` text NOT NULL,
  `pengaturan_alamat` text NOT NULL,
  `pengaturan_telp` varchar(100) NOT NULL,
  `pengaturan_fax` varchar(100) NOT NULL,
  `pengaturan_web` varchar(100) NOT NULL,
  `pengaturan_email` varchar(100) NOT NULL,
  `pengaturan_kab` varchar(100) NOT NULL,
  `pengaturan_pos` varchar(6) NOT NULL,
  `pengaturan_tgl_buka` date NOT NULL,
  `pengaturan_jam_buka` time NOT NULL,
  `pengaturan_tahun` varchar(5) NOT NULL,
  `pengaturan_nomor` varchar(20) NOT NULL,
  `pengaturan_password` text NOT NULL,
  `pengaturan_login_img` varchar(50) NOT NULL,
  `pengaturan_kop_img` varchar(50) NOT NULL,
  `pengaturan_ttd_img` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengaturan`
--

INSERT INTO `pengaturan` (`pengaturan_id`, `pengaturan_sekolah`, `pengaturan_alamat`, `pengaturan_telp`, `pengaturan_fax`, `pengaturan_web`, `pengaturan_email`, `pengaturan_kab`, `pengaturan_pos`, `pengaturan_tgl_buka`, `pengaturan_jam_buka`, `pengaturan_tahun`, `pengaturan_nomor`, `pengaturan_password`, `pengaturan_login_img`, `pengaturan_kop_img`, `pengaturan_ttd_img`) VALUES
(1, 'SMA Negeri 1 Yogyakarta', 'Jalan HOS Cokroaminoto No. 10 ', '0274 513454', '0274 542604', 'http://sman1yogya.sch.id', 'humas@sman1yogya.sch.id', 'Yogyakarta', '55253', '2020-05-02', '10:00:00', '2020', '123/2020', 'Rahasia123456', 'b6474a361047b4ce922e887bc129d059.jpg', '926ee8eb19e1e6cf90e45d4c62741848.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `siswa_id` int(11) NOT NULL,
  `siswa_nis` varchar(6) NOT NULL,
  `siswa_nisn` varchar(15) NOT NULL,
  `siswa_nama` varchar(50) NOT NULL,
  `siswa_kelas` varchar(15) NOT NULL,
  `siswa_absen` varchar(3) NOT NULL,
  `siswa_tmp_lahir` varchar(100) NOT NULL,
  `siswa_tgl_lahir` date NOT NULL,
  `siswa_ortu` varchar(200) NOT NULL,
  `siswa_tahun_lulus` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`siswa_id`, `siswa_nis`, `siswa_nisn`, `siswa_nama`, `siswa_kelas`, `siswa_absen`, `siswa_tmp_lahir`, `siswa_tgl_lahir`, `siswa_ortu`, `siswa_tahun_lulus`) VALUES
(1, '12345', '123456789', 'Sopan Setiawan', 'XII MIPA 1', '1', 'Yogya', '1992-05-12', 'Sarmidi 1', '2020'),
(2, '12346', '123456789', 'Umi Khoriyah', 'XII MIPA 2', '2', 'Bantul', '1992-05-13', 'Sarmidi 2', '2020'),
(3, '12347', '123456789', 'Muthiiah Arrumaisha', 'XII MIPA 3', '3', 'Sleman', '1992-05-14', 'Sarmidi 3', '2020'),
(4, '12348', '123456789', 'Yuni Ika Erawati', 'XII MIPA 4', '4', 'Wates', '1992-05-15', 'Sarmidi 4', '2020'),
(5, '12349', '123456789', 'Arfinda Ilmania', 'XII MIPA 5', '5', 'Yogya', '1992-05-16', 'Sarmidi 5', '2020'),
(6, '12350', '123456789', 'Rafiq Anwar', 'XII MIPA 6', '6', 'Bantul', '1992-05-17', 'Sarmidi 6', '2020'),
(7, '12351', '123456789', 'Agus Aryanto', 'XII MIPA 7', '7', 'Sleman', '1992-05-18', 'Sarmidi 7', '2020'),
(8, '12352', '123456789', 'Kustriyanto', 'XII MIPA 8', '8', 'Wates', '1992-05-19', 'Sarmidi 8', '2020'),
(9, '12353', '123456789', 'Nuriah Indrarini', 'XII MIPA 9', '9', 'Yogya', '1992-05-20', 'Sarmidi 9', '2020'),
(10, '98756', '123456789', 'Shinta', 'XII MIPA 1', '10', 'Yogya', '1992-05-12', 'Sarmidi 1', '2020'),
(11, '87546', '123456789', 'Rosita', 'XII MIPA 2', '11', 'Bantul', '1992-05-13', 'Sarmidi 2', '2020'),
(12, '54652', '123456789', 'Untung Sadermo', 'XII MIPA 3', '12', 'Sleman', '1992-05-14', 'Sarmidi 3', '2020'),
(13, '87543', '123456789', 'Dian Untari', 'XII MIPA 4', '13', 'Wates', '1992-05-15', 'Sarmidi 4', '2020'),
(14, '89754', '123456789', 'Refli Harun', 'XII MIPA 5', '14', 'Yogya', '1992-05-16', 'Sarmidi 5', '2020'),
(15, '98754', '123456789', 'Miftakodin', 'XII MIPA 8', '17', 'Wates', '1992-05-19', 'Sarmidi 8', '2020'),
(16, '84576', '123456789', 'Kusyanto', 'XII MIPA 7', '16', 'Sleman', '1992-05-18', 'Sarmidi 7', '2020'),
(17, '23546', '123456789', 'Asrori', 'XII MIPA 9', '18', 'Yogya', '1992-05-20', 'Sarmidi 9', '2020'),
(18, '88754', '123456789', 'Bambang Kusnanti', 'XII MIPA 6', '15', 'Bantul', '1992-05-17', 'Sarmidi 6', '2020');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mapel`
--
ALTER TABLE `mapel`
  ADD PRIMARY KEY (`mapel_id`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`nilai_id`);

--
-- Indexes for table `pengaturan`
--
ALTER TABLE `pengaturan`
  ADD PRIMARY KEY (`pengaturan_id`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`siswa_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mapel`
--
ALTER TABLE `mapel`
  MODIFY `mapel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `nilai_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `pengaturan`
--
ALTER TABLE `pengaturan`
  MODIFY `pengaturan_id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `siswa_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
