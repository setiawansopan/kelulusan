<ul class="nav justify-content-center">
	<li class="nav-item">
		<a class="nav-link" href="<?php echo base_url(); ?>index.php/admin_con">Home</a> 
	</li>
	<li class="nav-item dropdown">
		<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      	Upload
    	</a>
    	<div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="<?php echo base_url(); ?>index.php/admin_con/siswa">Upload Siswa</a>
          <a class="dropdown-item" href="<?php echo base_url(); ?>index.php/admin_con/nilai">Upload Nilai</a>
          <a class="dropdown-item" href="<?php echo base_url(); ?>index.php/admin_con/file">Upload File</a>
        </div>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo base_url(); ?>index.php/admin_con/mapel">Daftar Mapel </a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo base_url(); ?>index.php/admin_con/lihat">Lihat Nilai </a>
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo base_url(); ?>index.php/admin_con/pengaturan">Pengaturan </a> 
	</li>
	<li class="nav-item">
		<a class="nav-link" href="<?php echo base_url(); ?>index.php/admin_con/logout">Logout </a> 
	</li>
</ul>
