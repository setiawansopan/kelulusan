<!DOCTYPE html>
<html>
<?php
$this->load->view('admin/header');
?>
<body>
<header>
<h1 align="center">SELAMAT DATANG DI DASHBOARD ADMIN KELULUSAN</h1>
<?php
$this->load->view('admin/navigasi');
?>
</header>
<br>
<div class="container">
<h4>Tambah Mata Pelajaran</h4>
<form action="<?php echo base_url('index.php/admin_con/mapel_simpan')?>" method="POST">
	<div class="row">
		<div class="form-group col-md-4">
		<label for="Nama Mapel">Nama</label>
		<input type="text" class="form-control form-control-sm" name="mapel_nama" required="Flags">
		</div>
		<div class="form-group col-md-2">
		<label for="Kode">Kode</label>
		<input type="text" class="form-control form-control-sm" name="mapel_kode" required="Flags">
		</div>
		<div class="form-group col-md-2">
		<label for="Kelompok">Kelompok</label>
		<select name="mapel_kelompok" class="form-control form-control-sm" required="Flags">
				<option value="">Pilih..</option>
				<option value="A">Kelompok A</option>
				<option value="B">Kelompok B</option>
				<option value="C">Kelompok C</option>
			</select>
		</div>
	</div>
	<div class="row">
		<div class="col">
		<input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
	 	</div>
	 </div>
</form>
<br>
<h4>Daftar mata pelajaran</h4>
<table width="50%" cellpadding="4" cellspacing="0" border="1" class="table table-striped table-hover table-sm">
	<tr  class="thead-dark">
		<th>No</th>
		<th>Nama Mata Pelajaran</th>
		<th>Kode</th>
		<th>Kelompok</th>
		<th>Aksi</th>
	</tr>
	<?php 
		$no = 1;
		foreach ($mapel as $value) {
		?>
			<tr>
				<td align="center"><?php echo $no; ?></td>
				<td><?php echo $value['mapel_nama']; ?></td>
				<td align="center"><?php echo $value['mapel_kode']; ?></td>
				<td align="center"><?php echo $value['mapel_kelompok']; ?></td>
				<td align="center">
					<a class="btn btn-danger btn-sm" href="<?php echo base_url('index.php/admin_con/mapel_hapus')?>?mapel_id=<?php echo $value['mapel_id']?>">Hapus</a>
				</td>
			</tr>
		<?php 
		$no++;
		}
	?>
</table>
</div>
</body>
</html>