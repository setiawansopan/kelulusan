<!DOCTYPE html>
<html>
<?php
$this->load->view('admin/header');
?>
<body>
<header>

<h1 align="center">SELAMAT DATANG DI DASHBOARD ADMIN KELULUSAN</h1>
<?php
$this->load->view('admin/navigasi');
?>
</header>
	<br>
<div class="container">
<h4>Data Sekolah</h4>
<form action="<?php echo base_url('index.php/admin_con/pengaturan_simpan'); ?>" method="POST" enctype="multipart/form-data">
	<div class="col-md-6">
		<div class="form-group">
		<label for="Nama Sekolah">Nama Sekolah</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_sekolah" size="40" value="<?php echo $pengaturan->pengaturan_sekolah?>" />
		</div>
		<div class="form-group">
		<label for="Alamat Sekolah">Alamat Sekolah</label>
		<textarea  class="form-control form-control-sm" cols="50" rows="3" name="pengaturan_alamat"><?php echo $pengaturan->pengaturan_alamat?></textarea>
		</div>
		<div class="form-group">
		<label for="Nama Sekolah">Telpon Sekolah</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_telp" size="40" value="<?php echo $pengaturan->pengaturan_telp?>" />
		</div>
		<div class="form-group">
		<label for="Nama Sekolah">Fax Sekolah</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_fax" size="40" value="<?php echo $pengaturan->pengaturan_fax?>" />
		</div>
		<div class="form-group">
		<label for="Nama Sekolah">Web Sekolah</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_web" size="40" value="<?php echo $pengaturan->pengaturan_web?>" />
		</div>
		<div class="form-group">
		<label for="Nama Sekolah">Email Sekolah</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_email" size="40" value="<?php echo $pengaturan->pengaturan_email?>" />
		</div>
		<div class="form-group">
		<label for="Nama Sekolah">Kabupaten </label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_kab" size="40" value="<?php echo $pengaturan->pengaturan_kab?>" />
		</div>
		<div class="form-group">
		<label for="Nama Sekolah">Kode Pos</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_pos" size="40" value="<?php echo $pengaturan->pengaturan_pos?>" />
		</div>
		<br>
		<h4>Buka Akses</h4>
		<div class="form-group">
		<label for="Tanggal Buka">Tanggal Buka</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_tgl_buka" size="40" value="<?php echo $pengaturan->pengaturan_tgl_buka?>" /></
		</div>
		<div class="form-group">
		<label for="Jam Buka">Jam Buka</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_jam_buka" size="40" value="<?php echo $pengaturan->pengaturan_jam_buka?>" /></
		</div>
		<br>
		<h4>Nomor Surat</h4>
		<div class="form-group">
		<label for="Nomor Surat">Nomor Surat</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_nomor" size="40" value="<?php echo $pengaturan->pengaturan_nomor?>" /></
		</div>
		<br>
		<h4>Tahun Aktif</h4>
		<div class="form-group">
		<label for="Tahun Aktif">Tahun Aktif</label>
		<input type="text"  class="form-control form-control-sm" name="pengaturan_tahun" size="40" value="<?php echo $pengaturan->pengaturan_tahun?>" /></
		</div>
		<br>
		<h4>Password Admin</h4>
		<div class="form-group">
		<label for="Password">Password</label>
		<input type="password"  class="form-control form-control-sm" name="pengaturan_password" value="<?php echo $pengaturan->pengaturan_password?>"></td>
		</div>
		<input type="submit" value="Simpan" class="btn btn-primary" />
	</div>
</form>
</div>
</body>
</html>