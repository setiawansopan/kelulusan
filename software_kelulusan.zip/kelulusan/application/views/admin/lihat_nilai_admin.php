<!DOCTYPE html>
<html>
<?php
$this->load->view('admin/header');
?>
<body>
	<div class="container-fluid">
		<header>
		<h1 align="center">SELAMAT DATANG DI DASHBOARD ADMIN KELULUSAN</h1>
		<?php
		$this->load->view('admin/navigasi');
		?>
		</header>
		<br>

		<h4>Daftar Nilai Siswa Lulusan Tahun <?php echo $this->session->tahun; ?></h4>
		<table class="table table-striped table-hover table-sm">
			<thead>
			<tr>
				<td>No</td>
				<td>NIS</td>
				<td>Nama</td>
				<td>Kelas</td>
				<?php 
				foreach ($mapel as $value) { ?>
				<td title="<?php echo $value['mapel_nama'] ?>"><?php echo $value['mapel_kode'] ?></td>
				<?php } ?>
			</tr>
			</thead>
			<tbody>
			<?php 
			$no = 1;
			foreach ($siswa as $row) { ?>
			<tr>
				<td><?php echo $no; ?></td>
				<td><?php echo $row['siswa_nis'] ; ?></td>
				<td><?php echo $row['siswa_nama'] ; ?></td>
				<td><?php echo $row['siswa_kelas'] ; ?></td>
				<?php 
				foreach ($mapel as $map) { ?>
				<td>
				<?php 
				foreach ($nilai as $col) { 
				if ($col['nilai_siswa_nis'] == $row['siswa_nis'] && $col['nilai_mapel_id'] == $map['mapel_id'])
		 		echo $col['nilai_angka']; 
				}
				?>
				</td>
				<?php } ?>
			</tr>
			<?php $no++; }  ?>
			</tbody>

		</table>
		
	</div>

</body>
</html>