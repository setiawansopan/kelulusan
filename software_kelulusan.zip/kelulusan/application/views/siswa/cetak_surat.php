<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body, td, th {
            font-family: Arial, Helvetica, sans-serif;
            /*font-size: 13px;*/
        }

        table {
            border-collapse: collapse;
        }

        .kop p {
            margin: 0px !important;
        }

        .title h3, .title p {
            margin: 0px !important;
        }

        .identitas {
            margin: 10px 0px;
        }

        .hasil {
            font-style: italic;
        }

        .hasil h2 {
            margin: 10px 0px;
        }

        .nilai {
            font-size: 15px;
        }

        .nilai td {
            padding: 0px 10px;
            vertical-align: top;
        }

        .print-container {
            width: 95%;
            margin: auto;
        }

        @media print {
          body * {
            visibility: hidden;
          }
          #printarea, #printarea * {
            visibility: visible;
          }
          #printarea {
            position: absolute;
            left: 0;
            top: 0;
          }
        }

    </style>
</head>
<body>
    <div align="right">
        <a href="#" onclick="window.print();return false;"><img style="height: 25px" src="<?php echo base_url(); ?>images/print.png"></a>
    </div>
    <div id="printarea">
        <div class="print-container">
            <table class="kop" width="100%">
                <tr>
                    <td width="15%" align="center">
                        <img style="height: 100px" src="<?php echo base_url(); ?>images/logo_diy.png">
                    </td>
                    <td width="70%" align="center">
                        <p style="font-size: 17px">PEMERINTAH DAERAH DAERAH ISTIMEWA YOGYAKARTA<br>DINAS PENDIDIKAN, PEMUDA DAN OLAHRAGA</p>
                        <p style="font-size: 20px"><strong><?php echo strtoupper($pengaturan->pengaturan_sekolah); ?></strong></p>
                        <img style="height: 30px" src="<?php echo base_url('images/upload/').$pengaturan->pengaturan_kop_img; ?>">
                        <p style="font-size: 12px"><?php echo $pengaturan->pengaturan_alamat." Telp. ".$pengaturan->pengaturan_telp.", Fak ".$pengaturan->pengaturan_fax." ".$pengaturan->pengaturan_kab." ".$pengaturan->pengaturan_pos; ?>
                        <!-- <p style="font-size: 12px">JL. HOS Cokroaminoto 10 Telp. 0274-513454, Fak 0274-542604 Yogyakarta 55253 -->
                            <br><?php echo "Website : ".$pengaturan->pengaturan_web." ; e-mail : ".$pengaturan->pengaturan_email; ?></p>
                    </td>
                    <td width="15%" align="center">
                    </td>
                </tr>
            </table>
            <center>
                <img style="width: 100%; height: 10px;" src="<?php echo base_url(); ?>images/line.png">
            </center>
            <div class="title">
                <center>
                    <h3 style="font-size: 16px"><u>SURAT KETERANGAN</u></h3>
                    <p>No : <?php echo $pengaturan->pengaturan_nomor; ?></p>
                </center>
            </div>
            <table class="identitas" width="100%">
                <tr>
                    <td colspan="2">Yang bertanda tangan dibawah ini,  Kepala Sekolah Menengah Atas Negeri 1 Yogyakarta,
                    Nomor Pokok Sekolah Nasional 20403174, Kota Yogyakarta, menerangkan bahwa :</td>
                </tr>
                <tr>
                    <td width="40%">nama </td><td width="60%">: <?php echo strtoupper($siswa->siswa_nama); ?></td>
                </tr>
                <tr>
                    <td>tempat dan tanggal lahir </td><td>: <?php echo $siswa->siswa_tmp_lahir.", ".tanggal($siswa->siswa_tgl_lahir); ?></td>
                </tr>
                <tr>
                    <td>nama orangtua/wali </td><td>: <?php echo $siswa->siswa_ortu; ?></td>
                </tr>
                <tr>
                    <td>nomor induk siswa </td><td>: <?php echo $siswa->siswa_nis; ?></td>
                </tr>
                <tr>
                    <td>nomor induk siswa nasional </td><td>: <?php echo $siswa->siswa_nisn; ?></td>
                </tr>
                <tr>
                    <td>kelas / no. presensi </td><td>: <?php echo $siswa->siswa_kelas." / ".$siswa->siswa_absen; ?></td>
                </tr>
                <tr>
                    <td colspan="3">
                        <div class="hasil">
                            <center>
                                <h2>L U L U S</h2>
                            </center>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">dari sekolah menengah atas pada tanggal <?php echo tanggal($pengaturan->pengaturan_tgl_buka) ?>, setelah memenuhi seluruh kriteria sesuai dengan peraturan perundang-undangan dengan nilai sebagai berikut :</td>
                </tr>
            </table>
            <table class="nilai" width="100%" cellspacing="4" border="1">
                <thead>
                    <tr>
                        <td width="7%" align="center">No</td>
                        <td width="68%" align="center">Mata Pelajaran</td>
                        <td width="25%" align="center">Nilai Ujian Sekolah</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="3">Kelompok A</td>
                    </tr>
                    <?php if($mapelA != null) {
                        $no_a = 1; foreach ($mapelA as $value1) { ?>
                        <tr>
                            <td align="center"><?php echo $no_a; ?></td>
                            <td><?php echo $value1['mapel_nama'] ?></td>
                            <td align="center"><?php echo $value1['nilai_angka'] ?></td>
                        </tr>
                    <?php $no_a++;} } ?>
                    <tr>
                        <td colspan="3">Kelompok B</td>
                    </tr>
                    <?php if($mapelA != null) {
                        $no_b = 1; foreach ($mapelB as $value1) { ?>
                        <tr>
                            <td align="center"><?php echo $no_b; ?></td>
                            <td><?php echo $value1['mapel_nama'] ?></td>
                            <td align="center"><?php echo $value1['nilai_angka'] ?></td>
                        </tr>
                    <?php $no_b++;} } ?>
                    <tr>
                        <td colspan="3">Kelompok C</td>
                    </tr>
                    <?php if($mapelA != null) {
                        $no_c = 1; foreach ($mapelC as $value1) { ?>
                        <tr>
                            <td align="center"><?php echo $no_c; ?></td>
                            <td><?php echo $value1['mapel_nama'] ?></td>
                            <td align="center"><?php echo $value1['nilai_angka'] ?></td>
                        </tr>
                    <?php $no_c++;} } ?>
                    <tr>
                        <td colspan="2" align="center">Rata-rata</td>
                        <td align="center"><?php echo number_format($rata_rata->nilai, 2); ?></td>
                    </tr>
                </tbody>
            </table>
            <p style="margin: 10px 0px;">Demikian, Surat Keterangan ini diberikan untuk dapat digunakan sebelum diterbitkan ijazah tahun pelajaran 2019/2020.</p>
            <table width="40%" align="right">
                <tr>
                    <td>Yogyakarta, <?php echo tanggal($pengaturan->pengaturan_tgl_buka) ?> <br>
                    Kepala Sekolah,</td>
                </tr>
               <tr>
                    <td>
                        <?php if($pengaturan->pengaturan_ttd_img != null) { ?>
                            <img style="height: 55px" src="<?php echo base_url('images/upload/').$pengaturan->pengaturan_ttd_img; ?>">
                        <?php } else { ?>
                            <br><br><br>
                        <?php } ?>
                    </td>
                
                </tr>
                <tr>
                    <td>Drs. MIFTAKODIN, MM. <br>
                    NIP : 19680813 199402 1 001</td>
                </tr>
            </table>
        </div>
        <div style="clear: both;"></div>
    </div>
</body>
</html>