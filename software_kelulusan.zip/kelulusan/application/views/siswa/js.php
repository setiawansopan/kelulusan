

<!-- jQuery UI -->
<script src="<?php echo base_url(); ?>assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

<!-- jQuery Scrollbar -->
<script src="<?php echo base_url(); ?>assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>

<!-- Moment JS -->
<script src="<?php echo base_url(); ?>assets/js/plugin/moment/moment.min.js"></script>

<!-- jQuery Sparkline -->
<script src="<?php echo base_url(); ?>assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>

<!-- Datatables -->
<script src="<?php echo base_url(); ?>assets/js/plugin/datatables/datatables.min.js"></script>

<!-- Bootstrap Toggle -->
<script src="<?php echo base_url(); ?>assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>

<!-- Dropzone -->
<script src="<?php echo base_url(); ?>assets/js/plugin/dropzone/dropzone.min.js"></script>

<!-- DateTimePicker -->
<script src="<?php echo base_url(); ?>assets/js/plugin/datepicker/bootstrap-datetimepicker.min.js"></script>

<!-- Bootstrap Tagsinput -->
<script src="<?php echo base_url(); ?>assets/js/plugin/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>

<!-- Bootstrap Wizard -->
<script src="<?php echo base_url(); ?>assets/js/plugin/bootstrap-wizard/bootstrapwizard.js"></script>

<!-- jQuery Validation -->
<script src="<?php echo base_url(); ?>assets/js/plugin/jquery.validate/jquery.validate.min.js"></script>

<!-- Select2 -->
<script src="<?php echo base_url(); ?>assets/js/plugin/select2/select2.full.min.js"></script>

<!-- Atlantis JS -->
<script src="<?php echo base_url(); ?>assets/js/atlantis2.min.js"></script>

