<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Data Siswa</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<!-- <link rel="icon" href="<?php echo base_url(); ?>assets/img/icon.ico" type="image/x-icon"/> -->

	<!-- Fonts and icons -->
	<script src="<?php echo base_url(); ?>assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['<?php echo base_url(); ?>assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/atlantis2.css">
</head>
<body>
	<div class="wrapper">
		<div class="main-header" data-background-color="purple">
			<div class="nav-top">
				<div class="container d-flex flex-row">
					<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon">
							<i class="icon-menu"></i>
						</span>
					</button>
					<button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
					<!-- Logo Header -->
					<a href="index.html" class="logo d-flex align-items-center">
						<!-- <img src="<?php echo base_url(); ?>assets/img/logo.svg" alt="navbar brand" class="navbar-brand"> -->
					</a>
					<!-- End Logo Header -->

					<!-- Navbar Header -->
					<nav class="navbar navbar-header navbar-expand-lg p-0">

						<div class="container-fluid p-0">
							<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
								<li class="nav-item" style="color: white">
									<span><?php echo $this->session->user_nama; ?></span>
								</li>
								<li class="nav-item">
									<a class="nav-link" href="<?php echo base_url("siswa_con/logout"); ?>" role="button" title="Keluar">
										<i class="fa fa-sign-out-alt"></i>
									</a>
									
								</li>
							</ul>
						</div>
					</nav>
					<!-- End Navbar -->
				</div>
			</div>
			<div class="nav-bottom bg-white">
				<h3 class="title-menu d-flex d-lg-none"> 
					Menu 
					<div class="close-menu"> <i class="flaticon-cross"></i></div>
				</h3>
				<div class="container d-flex flex-row">
					<ul class="nav page-navigation page-navigation-secondary">
						<li class="nav-item active">
							<a class="nav-link" href="#">
								<i class="link-icon icon-screen-desktop"></i>
								<span class="menu-title">Data Siswa</span>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="main-panel">
			<div class="container">
				<div class="page-inner">
					<div class="row row-card-no-pd">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="card-head-row">
										<h4 class="card-title">Data Nilai Siswa</h4>
									</div>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group row">
												<label class="col-lg-3 col-md-3 control-label">
													Nama
												</label> 
												<div class="col-lg-9 col-md-9">
													<span>: <?php echo $siswa->siswa_nama; ?></span>
												</div>
											</div>
											<div class="form-group row">
												<label class="col-lg-3 col-md-3 control-label">
													Tempat dan tanggal lahir
												</label> 
												<div class="col-lg-9 col-md-9">
													<span>: <?php echo $siswa->siswa_tmp_lahir.", ".tanggal($siswa->siswa_tgl_lahir); ?></span>
												</div>
											</div>
											<div class="form-group row">
												<label class="col-lg-3 col-md-3 control-label">
													Nama orang tua/wali
												</label> 
												<div class="col-lg-9 col-md-9">
													<span>: <?php echo $siswa->siswa_ortu; ?></span>
												</div>
											</div>
											<div class="form-group row">
												<label class="col-lg-3 col-md-3 control-label">
													Nomor induk siswa
												</label> 
												<div class="col-lg-9 col-md-9">
													<span>: <?php echo $siswa->siswa_nis; ?></span>
												</div>
											</div>
											<div class="form-group row">
												<label class="col-lg-3 col-md-3 control-label">
													Nomor induk siswa nasional
												</label> 
												<div class="col-lg-9 col-md-9">
													<span>: <?php echo $siswa->siswa_nisn; ?></span>
												</div>
											</div>
											<div class="form-group row">
												<label class="col-lg-3 col-md-3 control-label">
													Kelas / no.presensi
												</label> 
												<div class="col-lg-9 col-md-9">
													<span>: <?php echo $siswa->siswa_kelas." / ".$siswa->siswa_absen; ?></span>
												</div>
											</div>
											<div class="form-group row">
												<label class="col-lg-3 col-md-3 control-label">
													Dinyatakan
												</label> 
												<div class="col-lg-9 col-md-9">
													<span>: <span style="font-size: 24px">L U L U S</span></span>
												</div>
											</div>
											<div class="form-group row">
												<div class="col-md-12">
													<span>dari sekolah menengah atas setelah memenuhi seluruh kriteria sesuai dengan peraturan perundang-undangan dengan nilai sebagai berikut :</span>
												</div>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<div class="table-responsive table-hover table-sales">
												<table class="table table-bordered table-head-bg-info table-bordered-bd-info mt-4">
													<thead>
														<tr>
															<th width="10%" class="text-center" scope="col">No</th>
															<th width="65%" class="text-center" scope="col">Mata Pelajaran</th>
															<th width="25%" class="text-center" scope="col">Nilai Ujian Sekolah</th>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td colspan="3">Kelompok A</td>
														</tr>
														<?php if($mapelA != null) {
															$no_a = 1; foreach ($mapelA as $value1) { ?>
															<tr>
																<td><?php echo $no_a; ?></td>
																<td><?php echo $value1['mapel_nama'] ?></td>
																<td class="text-center"><?php echo $value1['nilai_angka'] ?></td>
															</tr>
														<?php $no_a++;} } ?>
														<tr>
															<td colspan="3">Kelompok B</td>
														</tr>
														<?php if($mapelA != null) {
															$no_b = 1; foreach ($mapelB as $value1) { ?>
															<tr>
																<td><?php echo $no_b; ?></td>
																<td><?php echo $value1['mapel_nama'] ?></td>
																<td class="text-center"><?php echo $value1['nilai_angka'] ?></td>
															</tr>
														<?php $no_b++;} } ?>
														<tr>
															<td colspan="3">Kelompok C</td>
														</tr>
														<?php if($mapelA != null) {
															$no_c = 1; foreach ($mapelC as $value1) { ?>
															<tr>
																<td><?php echo $no_c; ?></td>
																<td><?php echo $value1['mapel_nama'] ?></td>
																<td class="text-center"><?php echo $value1['nilai_angka'] ?></td>
															</tr>
														<?php $no_c++;} } ?>
														<tr>
															<td colspan="2" class="text-center">Rata-rata</td>
															<td class="text-center"><?php echo number_format($rata_rata->nilai, 2); ?></td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<a target="_blank" href="<?php echo base_url('siswa_con/cetak_surat') ?>" class="btn btn-success"><i class="fa fa-print"></i> Cetak Surat</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<footer class="footer">
			<div class="container">
				<div class="copyright ml-auto">
					<p>&copy; Copyright 2019. All Rights Reserved by <a href="#">ICT Teladan</a></p>
				</div>				
			</div>
		</footer>
	</div>
	<?php $this->load->view("siswa/js"); ?>
</body>
</html>