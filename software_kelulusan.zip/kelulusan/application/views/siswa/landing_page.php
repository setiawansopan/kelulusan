<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Login</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<!-- <link rel="icon" href="<?php echo base_url(); ?>assets/img/icon.ico" type="image/x-icon"/> -->

	<!-- Fonts and icons -->
	<script src="<?php echo base_url(); ?>assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['<?php echo base_url(); ?>assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>
	
	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/atlantis.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
</head>
<body class="login">
	<div class="wrapper wrapper-login wrapper-login-full p-0">
		<div class="login-aside w-100 d-flex flex-column align-items-center justify-content-center text-center bg-landing-page">
			<h1>COMING SOON</h1>
			<br>
			<div class="col-lg-6 col-md-8 col-sm-12 row">
				<div class="col-sm-3 countdown-item">
					<div class="countdown-time" id="demo1"></div>
					<p class="countdown-text"><strong>days</strong></p>
				</div>
				<div class="col-sm-3 countdown-item">
					<div class="countdown-time" id="demo2"></div>
					<p class="countdown-text"><strong>hours</strong></p>
				</div>
				<div class="col-sm-3 countdown-item">
					<div class="countdown-time" id="demo3"></div>
					<p class="countdown-text"><strong>minutes</strong></p>
				</div>
				<div class="col-sm-3 countdown-item">
					<div class="countdown-time" id="demo4"></div>
					<p class="countdown-text"><strong>seconds</strong></p>
				</div>
		      
		    </div>
		</div>
	</div>
	<script src="<?php echo base_url(); ?>assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/core/popper.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/core/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/atlantis.min.js"></script>
	<script>
		// Set the date we're counting down to
		<?php $dateBuka = date("M d, Y H:i:s", strtotime($pengaturan->pengaturan_tgl_buka." ".$pengaturan->pengaturan_jam_buka)); ?>

		var countDownDate = new Date("<?php echo $dateBuka; ?>").getTime();

		// Update the count down every 1 second
		var x = setInterval(function() {

		  // Get today's date and time
		  var now = new Date().getTime();
		    
		  // Find the distance between now and the count down date
		  var distance = countDownDate - now;
		    
		  // Time calculations for days, hours, minutes and seconds
		  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
		  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
		  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
		  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
		    
		  // Output the result in an element with id="demo"
		  document.getElementById("demo1").innerHTML = days;
		  document.getElementById("demo2").innerHTML = hours;
		  document.getElementById("demo3").innerHTML = minutes;
		  document.getElementById("demo4").innerHTML = seconds;
		  
		  // document.getElementById("demo").innerHTML = days+"d "+hours+"h "+minutes+"m "+seconds+"s ";
		    
		  // If the count down is over, write some text 
		  if (distance < 0) {
		    clearInterval(x);
		    location.reload();
		  }
		}, 1000);
		// setTimeout(refresh, 10000);
	</script>
</body>
</html>