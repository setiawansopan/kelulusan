<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa_mod extends CI_Model {

	//---------------------------------
	//login
	//---------------------------------

	public function login_cek($username, $password)
	{        
		$this->db->select('*')
		->from('siswa')
		->where('siswa_nis', $username)
		->where('siswa_tgl_lahir', $password);
		$query = $this->db->get();
        return $query;
	}

	//---------------------------------
	//siswa
	//---------------------------------

	public function siswa_cek_nis($nis)
	{        
		$this->db->select('*')
		->from('siswa')
		->where('siswa_nis', $nis);
		$query = $this->db->get();
        return $query->row();
	}

	//---------------------------------
	//nilai
	//---------------------------------

	public function siswa_nilai($nis, $mapel_kelompok) {
		$query = $this->db->select('*')
		->from('nilai')
		->join('mapel', 'mapel_id = nilai_mapel_id')
		->join('siswa', 'siswa_nis = nilai_siswa_nis')
		->where('siswa_nis', $nis)
		->where('mapel_kelompok', $mapel_kelompok)
		->get();

		return $query->result_array();
	}

	public function nilai_rata_rata($nis) {
		$query = $this->db->select('avg(nilai_angka) as nilai')
		->from('nilai')
		->join('mapel', 'mapel_id = nilai_mapel_id')
		->join('siswa', 'siswa_nis = nilai_siswa_nis')
		->where('siswa_nis', $nis)
		->get();

		return $query->row();
	}

	public function pengaturan_ambil()
	{        
		$this->db->select('*')->from('pengaturan');
		$query = $this->db->get();
        return $query->row();
	}
}
