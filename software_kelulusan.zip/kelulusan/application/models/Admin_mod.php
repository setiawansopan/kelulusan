<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_mod extends CI_Model {

	//---------------------------------
	//login
	//---------------------------------
	public function login_cek($password) {
		$query = $this->db->select('*')
		->from('pengaturan')
		->where('pengaturan_password', $password)
		->get();

		return $query;
	}

	//---------------------------------
	//siswa
	//---------------------------------

	public function ambil_siswa($tahun)
	{
		$query = $this->db->select('*')
		->from('siswa')
		->where('siswa_tahun_lulus', $tahun)
		->order_by('siswa_kelas', 'siswa_absen')
		->get();

		return $query->result_array();
	}

	public function jumlah_siswa() {
		$query = $this->db->select('count(siswa_id) as jumlah')
		->from('siswa')
		->where('siswa_tahun_lulus', date('Y'))
		->get();
		return $query->row();
	}

	public function siswa_cek_nis($nis)
	{        
		$this->db->select('*')
		->from('siswa')
		->where('siswa_nis', $nis);
		$query = $this->db->get();
        return $query->row();
	}

	public function siswa_insert($data)
	{
		return $this->db->insert('siswa', $data);
	}

	public function siswa_update($nis, $data)
	{
		return $this->db->where('siswa_nis', $nis)->update('siswa', $data);
	}

	//---------------------------------
	//pengaturan
	//---------------------------------

	public function pengaturan_cek()
	{        
		$this->db->select('*')->from('pengaturan');
		$query = $this->db->get();
        return $query->row();
	}

	public function pengaturan_ambil()
	{        
		$this->db->select('*')->from('pengaturan');
		$query = $this->db->get();
        return $query->row();
	}

	public function pengaturan_insert($data)
	{
		return $this->db->insert('pengaturan', $data);
	}

	public function pengaturan_update($pengaturan_id, $data)
	{
		return $this->db->where('pengaturan_id', $pengaturan_id)->update('pengaturan', $data);
	}

	//---------------------------------
	//mapel
	//---------------------------------

	public function mapel_insert($data) {
		return $this->db->insert('mapel', $data);
	}	

	public function mapel_del($mapel_id) {
		return $this->db->where('mapel_id', $mapel_id)->delete('mapel');
	}

	public function ambil_mapel()
	{
		$query = $this->db->select('*')
		->from('mapel')
		->get();

		return $query->result_array();
	}

	public function ambil_mapel_byid($mapel_id)
	{
		$query = $this->db->select('*')
		->from('mapel')
		->where('mapel_id', $mapel_id)
		->get();

		return $query->row();
	}

	public function jumlah_mapel() {
		$query = $this->db->select('count(mapel_id) as jumlah')
		->from('mapel')
		->get();

		return $query->row();
	}

	//---------------------------------
	//nilai
	//---------------------------------

	public function nilai_insert($data) {
		$this->db->insert('nilai', $data);
	}

	public function nilai_update($nilai_id, $data)
	{
		return $this->db->where('nilai_id', $nilai_id)->update('nilai', $data);
	}

	public function cek_nilai($nis, $mapel_id)
	{     

		$data = array(
			'nilai_siswa_nis' => $nis,
			'nilai_mapel_id' => $mapel_id );

		$this->db->select('*')
		->from('nilai')
		->where($data);
		$query = $this->db->get();
        return $query->row();
	}

	public function ambil_nilai($tahun) {
		$query = $this->db->select('*')
		->from('nilai')
		->where('nilai_tahun', $tahun)
		->get();
		return $query->result_array();
	}

}
