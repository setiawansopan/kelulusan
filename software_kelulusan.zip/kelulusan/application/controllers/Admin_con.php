<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_con extends CI_Controller {

    //-------------------------------
    // Login halaman admin
    //-------------------------------

    public function login() {
        $this->load->view('admin/login');
    }

    public function auth($auth = null)
    {
        $this->load->model('admin_mod');

        $password = $this->input->post('password'); 
        
        $login = $this->admin_mod->login_cek($password);
        if($login->num_rows() != 0) {
            $status_login = TRUE;
            $tahun = $login->row()->pengaturan_tahun;
            //gawe session
            $this->session->set_userdata('status_login', $status_login);
            $this->session->set_userdata('tahun', $tahun);
            redirect(base_url('index.php/admin_con'));
        } else {
            $this->session->set_flashdata('error', 'password yang anda masukkan tidak sesuai');
            redirect(base_url('index.php/admin_con/login'));
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect(base_url('index.php/admin_con/login'));
    }

    //-------------------------------
    //navigasi halaman
    //-------------------------------

	public function index()
	{
    //cek login
    $status_login = $this->session->status_login;
    if($status_login == FALSE) {
        redirect(base_url('index.php/admin_con/login'));
    }

    $tahun = $this->session->tahun;
	$this->load->model('admin_mod');
	$data['siswa'] = $this->admin_mod->ambil_siswa($tahun);
    $data['hitung'] = $this->admin_mod->jumlah_siswa();
	$this->load->view('admin/dashboard_admin',$data);
	}

	public function siswa() {
    //cek login
    $status_login = $this->session->status_login;
    if($status_login == FALSE) {
        redirect(base_url('index.php/admin_con/login'));
    }

	$this->load->view('admin/upload_siswa_admin');
	}

	public function mapel() {
    //cek login
    $status_login = $this->session->status_login;
    if($status_login == FALSE) {
        redirect(base_url('index.php/admin_con/login'));
    }

	$this->load->model('admin_mod');
	$data['mapel'] = $this->admin_mod->ambil_mapel();
	$this->load->view('admin/mapel_admin', $data);	
	}

	public function nilai() {
    //cek login
    $status_login = $this->session->status_login;
    if($status_login == FALSE) {
        redirect(base_url('index.php/admin_con/login'));
    }

    $this->load->model('admin_mod');
    $data['mapel'] = $this->admin_mod->ambil_mapel();
	$this->load->view('admin/upload_nilai_admin', $data);
	}

    public function lihat() {
    //cek login
    $status_login = $this->session->status_login;
    if($status_login == FALSE) {
        redirect(base_url('index.php/admin_con/login'));
    }

    $tahun = $this->session->tahun;
    $this->load->model('admin_mod');
    $data['mapel'] = $this->admin_mod->ambil_mapel();
    $data['siswa'] = $this->admin_mod->ambil_siswa($tahun);
    $data['nilai'] = $this->admin_mod->ambil_nilai($tahun);
    $this->load->view('admin/lihat_nilai_admin', $data);
    }

    public function pengaturan() {
    //cek login
    $status_login = $this->session->status_login;
    if($status_login == FALSE) {
        redirect(base_url('index.php/admin_con/login'));
    }

    $this->load->model('admin_mod');
    $data['pengaturan'] = $this->admin_mod->pengaturan_ambil();
    $this->load->view('admin/pengaturan_admin', $data);
    }

   	public function file() {
    //cek login
    $status_login = $this->session->status_login;
    if($status_login == FALSE) {
        redirect(base_url('index.php/admin_con/login'));
    }

    $this->load->model('admin_mod');
    $data['pengaturan'] = $this->admin_mod->pengaturan_ambil();
    $this->load->view('admin/upload_file', $data);
    }

	//----------------------------
    //bagian upload daftar siswa
    //----------------------------
	public function siswa_upload() {

		require_once APPPATH.'third_party/PHPExcel.php';
        $this->load->model('admin_mod');
        $this->load->library('PHPExcel');
        $this->excel = new PHPExcel();

        $fileName = time().$_FILES['siswa_file']['name'];  
        $config['upload_path'] = 'fileExcel';                              
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 1000;
        $this->load->library('upload', $config);
    
        if (!$this->upload->do_upload('siswa_file'))
        {
            $this->upload->display_errors();
        }
        
        $media = $this->upload->data('siswa_file');

        $inputFileName = 'fileExcel/' . $fileName;
        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch (Exception $e) {
            die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
        }
 
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();
        for ($row = 2; $row <= $highestRow; $row++) {                           // Read a row of data into an array
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);
            
            $data['siswa'] = $this->admin_mod->siswa_cek_nis($rowData[0][0]);

            if(isset($data['siswa']) == false) {
                if($rowData[0][0] != null) {
                    $tgl_lhr = PHPExcel_Style_NumberFormat::toFormattedString($rowData[0][6],'DD-MM-YYYY' );

                    $dataSiswa = array(
                        'siswa_id' => '',
                        'siswa_nis' => $rowData[0][0], 
                        'siswa_nisn' => $rowData[0][1], 
                        'siswa_nama' => $rowData[0][2], 
                        'siswa_kelas' => $rowData[0][3],
                        'siswa_absen' => $rowData[0][4],
                        'siswa_tmp_lahir' => $rowData[0][5],
                        'siswa_tgl_lahir' => date('Y-m-d', strtotime($tgl_lhr)), 
                        'siswa_ortu' => $rowData[0][7],
                        'siswa_tahun_lulus' => $rowData[0][8]
                    );
                    $this->admin_mod->siswa_insert($dataSiswa);

                }
            } else {
                if($rowData[0][1] != null) {
                    $siswa_id = $data['siswa']->siswa_id;
                    $tgl_lhr = PHPExcel_Style_NumberFormat::toFormattedString($rowData[0][6],'DD-MM-YYYY' );
                    
                    $dataSiswa = array(
                        'siswa_nisn' => $rowData[0][1], 
                        'siswa_nama' => $rowData[0][2], 
                        'siswa_kelas' => $rowData[0][3],
                        'siswa_absen' => $rowData[0][4],
                        'siswa_tmp_lahir' => $rowData[0][5],
                        'siswa_tgl_lahir' => date('Y-m-d', strtotime($tgl_lhr)), 
                        'siswa_ortu' => $rowData[0][7],
                        'siswa_tahun_lulus' => $rowData[0][8]
                    );
                    $this->admin_mod->siswa_update($rowData[0][0], $dataSiswa);
                }
            }

        }

        $pathinfo = pathinfo($inputFileName);
        $dirname  = $pathinfo['dirname'];
        $filename = $pathinfo['filename'];
    
        $files = glob($dirname.'/'.$filename.'*');
        array_walk($files, function ($files) {
            if (file_exists($files)) {
                unlink($files);
            }
        });
        
        redirect(base_url('index.php/admin_con'));
	}

    //----------------------------
    //bagian mapel
    //----------------------------

    public function mapel_simpan() {
        $data = array(
            'mapel_nama' => $this->input->post('mapel_nama'),
            'mapel_kode' => $this->input->post('mapel_kode'),
            'mapel_kelompok' => $this->input->post('mapel_kelompok'),
            ); 
        $this->load->model('admin_mod');
        $this->admin_mod->mapel_insert($data);

        redirect(base_url('index.php/admin_con/mapel')); 
    }

    public function mapel_hapus() {
        $mapel_id = $this->input->get('mapel_id');
        $this->load->model('admin_mod');
        $this->admin_mod->mapel_del($mapel_id);

        redirect(base_url('index.php/admin_con/mapel')); 
    }

    //----------------------------
    //bagian pengaturan
    //----------------------------

    public function pengaturan_simpan() {
    $data_p = array(
        'pengaturan_sekolah' => $this->input->post('pengaturan_sekolah'),
        'pengaturan_alamat' => $this->input->post('pengaturan_alamat'),
        'pengaturan_telp' => $this->input->post('pengaturan_telp'),
        'pengaturan_fax' => $this->input->post('pengaturan_fax'),
        'pengaturan_web' => $this->input->post('pengaturan_web'),
        'pengaturan_email' => $this->input->post('pengaturan_email'),
        'pengaturan_kab' => $this->input->post('pengaturan_kab'),
        'pengaturan_pos' => $this->input->post('pengaturan_pos'),
        'pengaturan_tgl_buka' => $this->input->post('pengaturan_tgl_buka'),
        'pengaturan_jam_buka' => $this->input->post('pengaturan_jam_buka'),
        'pengaturan_nomor' => $this->input->post('pengaturan_nomor'),
        'pengaturan_tahun' => $this->input->post('pengaturan_tahun'),
        'pengaturan_password' => $this->input->post('pengaturan_password')
         );
    $this->load->model('admin_mod');
    $data['pengaturan'] = $this->admin_mod->pengaturan_cek();
    if(isset($data['pengaturan']) == false) {
        $this->admin_mod->pengaturan_insert($data_p);
    }
    else {
        $pengaturan_id = $data['pengaturan']->pengaturan_id;
        $this->admin_mod->pengaturan_update($pengaturan_id, $data_p);
    }

    redirect(base_url('index.php/admin_con/pengaturan'));
    }

    
    //--------------------------------------
    //bagian nilai
    //--------------------------------------

    public function download_format() {
        $mapel_id = $this->input->post('mapel_id');
        $tahun = $this->session->tahun;
        $this->load->model('admin_mod');
        $data['siswa'] = $this->admin_mod->ambil_siswa($tahun);
        $data['mapel'] = $this->admin_mod->ambil_mapel_byid($mapel_id);
        $data['hitung'] = $this->admin_mod->jumlah_mapel();
        $this->load->view('admin/download_format', $data);
    }

    public function nilai_upload() {

        require_once APPPATH.'third_party/PHPExcel.php';
        $this->load->model('admin_mod');
        $this->load->library('PHPExcel');
        $this->excel = new PHPExcel();

        $fileName = time().$_FILES['nilai_file']['name'];  
        $config['upload_path'] = 'fileExcel';                              
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 1000;
        $this->load->library('upload', $config);
    
        if (!$this->upload->do_upload('nilai_file'))
        {
            $this->upload->display_errors();
        }
        
        $media = $this->upload->data('nilai_file');

        $inputFileName = 'fileExcel/' . $fileName;
        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch (Exception $e) {
            die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
        }
 
        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();

        for ($row = 7; $row <= $highestRow; $row++) {                           // Read a row of data into an array
            $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);
            
            $data['nilai'] = $this->admin_mod->cek_nilai($rowData[0][1], $rowData[0][4]);
            $tahun = $this->session->tahun; 
            if(isset($data['nilai']) == false) {
                if($rowData[0][0] != null) {

                    $dataNilai = array(
                        'nilai_id' => '',
                        'nilai_siswa_nis' => $rowData[0][1], 
                        'nilai_mapel_id' => $rowData[0][4], 
                        'nilai_angka' => $rowData[0][5],
                        'nilai_tahun' => $tahun
                    );
                    $this->admin_mod->nilai_insert($dataNilai);

                }
            } else {
                if($rowData[0][1] != null) {
                    $nilai_id = $data['nilai']->nilai_id;
                    
                    $dataNilai = array(
                        'nilai_angka' => $rowData[0][5]
                    );
                    $this->admin_mod->nilai_update($nilai_id, $dataNilai);
                }
            }

        }

        $pathinfo = pathinfo($inputFileName);
        $dirname  = $pathinfo['dirname'];
        $filename = $pathinfo['filename'];
    
        $files = glob($dirname.'/'.$filename.'*');
        array_walk($files, function ($files) {
            if (file_exists($files)) {
                unlink($files);
            }
        });
        
        redirect(base_url('index.php/admin_con/lihat'));
    }

    //----------------------------
    //bagian upload file
    //----------------------------
    public function file_upload() {
        $this->load->model('admin_mod');

        $image_old1 = $this->input->post("gambar_login_old");
        $image_old2 = $this->input->post("gambar_kop_jawa_old");
        $image_old3 = $this->input->post("gambar_ttd_old");
        
        // gambar halaman login
        if (!empty($_FILES['gambar_login']['name'])  && $image_old1 !== ''){
            image_remove('images/upload', $image_old1);
            
            $image_upload1 = image_upload('images/upload', 'gambar_login');
        } elseif (!empty($_FILES['gambar_login']['name']) ){
            $image_upload1 = image_upload('images/upload', 'gambar_login');
        } else {
            $image_upload1 = $image_old1;
        }

        // gambar kop aksara jawa
        if (!empty($_FILES['gambar_kop_jawa']['name'])  && $image_old2 !== ''){
            image_remove('images/upload', $image_old2);
            
            $image_upload2 = image_upload('images/upload', 'gambar_kop_jawa');
        } elseif (!empty($_FILES['gambar_kop_jawa']['name']) ){
            $image_upload2 = image_upload('images/upload', 'gambar_kop_jawa');
        } else {
            $image_upload2 = $image_old2;
        }

        // gambar tanda tangan kepala sekolah
        if (!empty($_FILES['gambar_ttd']['name'])  && $image_old3 !== ''){
            image_remove('images/upload', $image_old3);
            
            $image_upload3 = image_upload('images/upload', 'gambar_ttd');
        } elseif (!empty($_FILES['gambar_ttd']['name']) ){
            $image_upload3 = image_upload('images/upload', 'gambar_ttd');
        } else {
            $image_upload3 = $image_old3;
        }

        $data = array(
            'pengaturan_login_img'       => $image_upload1,
            'pengaturan_kop_img'         => $image_upload2,
            'pengaturan_ttd_img'         => $image_upload3,
        );

        $update = $this->admin_mod->pengaturan_update(1, $data);
        if ($update) {
            $this->session->set_flashdata('success', 'Gambar berhasil ditambahkan');
        } else {
            $this->session->set_flashdata('error', 'Gambar gagal ditambahkan!');
        }
        redirect($this->input->server('HTTP_REFERER', TRUE), 'location');

    }
}

