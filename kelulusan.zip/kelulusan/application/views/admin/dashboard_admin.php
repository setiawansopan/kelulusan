<!DOCTYPE html>
<html>
<?php
$this->load->view('admin/header');
?>
<body>
<header>
<h1 align="center">SELAMAT DATANG DI DASHBOARD ADMIN KELULUSAN</h1>

<?php
$this->load->view('admin/navigasi');
?>
</header>
<br>
<div class="container">

<h4>Daftar Siswa Lulusan Tahun <?php echo date('Y')?> (<?php echo $hitung->jumlah; ?> Siswa)</h4>
		
<table width="100%" cellpadding="4" cellspacing="0" border="1" class="table table-striped table-hover table-sm">
	<thead class="thead-dark">
	<tr>
		<th>No</th>
		<th>NIS</th>
		<th>NISN</th>
		<th>Kelas/Abs</th>
		<th>Nama</th>
		<th>Tempat Lahir</th>
		<th>Tgl Lahir</th>
		<th>Nama Orang Tua</th>
	</tr>
	</thead>
	<tbody>
	<?php 
		$no = 1;
		foreach ($siswa as $value) {
		?>
			<tr>
				<td align="center"><?php echo $no; ?></td>
				<td align="center"><?php echo $value['siswa_nis']; ?></td>
				<td align="center"><?php echo $value['siswa_nisn']; ?></td>
				<td align="center"><?php echo $value['siswa_kelas']; ?> / <?php echo $value['siswa_absen']; ?></td>
				<td><?php echo $value['siswa_nama']; ?></td>
				<td align="center"><?php echo $value['siswa_tmp_lahir']; ?></td>
				<td align="center"><?php echo $value['siswa_tgl_lahir']; ?></td>
				<td align="center"><?php echo $value['siswa_ortu']; ?></td>
			</tr>
		<?php 
		$no++;
		}
	?>
	</tbody>
	</table>

</div>

</body>
</html>