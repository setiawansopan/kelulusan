<!DOCTYPE html>
<html>
<?php
$this->load->view('admin/header');
?>
<body>
<header>
<h1 align="center">SELAMAT DATANG DI DASHBOARD ADMIN KELULUSAN</h1>
<?php
$this->load->view('admin/navigasi');
?>
</header>
<div class="container">
	<br>
<h4>Upload data siswa lulusan tahun <?php echo date('Y'); ?></h4>

<form action="<?php echo base_url('admin_con/siswa_upload'); ?>" method="POST" enctype="multipart/form-data">
	<div class="form-group">
		<input type="file" class="form-control-file" name="siswa_file"  /></td></tr>
	</div>
	<input type="submit" value="Upload Data" class="btn btn-primary" /></td></tr>
</form>
</div>
</body>
</html>