<nav align="center" class="nav justify-content-center">
<a class="nav-link" href="<?php echo base_url(); ?>">Home</a> 
<a class="nav-link" href="<?php echo base_url(); ?>admin_con/siswa">Upload Siswa </a>
<a class="nav-link" href="<?php echo base_url(); ?>admin_con/mapel">Daftar Mapel </a>
<a class="nav-link" href="<?php echo base_url(); ?>admin_con/nilai">Upload Nilai </a>
<a class="nav-link" href="<?php echo base_url(); ?>admin_con/nilai">Lihat Nilai </a>
<a class="nav-link" href="<?php echo base_url(); ?>admin_con/pengaturan">Pengaturan </a> 
</nav>



