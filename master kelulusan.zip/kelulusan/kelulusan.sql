-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2020 at 05:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kelulusan`
--

-- --------------------------------------------------------

--
-- Table structure for table `mapel`
--

CREATE TABLE `mapel` (
  `mapel_id` int(11) NOT NULL,
  `mapel_nama` varchar(100) NOT NULL,
  `mapel_kode` varchar(10) NOT NULL,
  `mapel_kelompok` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mapel`
--

INSERT INTO `mapel` (`mapel_id`, `mapel_nama`, `mapel_kode`, `mapel_kelompok`) VALUES
(1, 'Pendidikan Agama dan Budi Pekerti', 'pab', 'A'),
(2, 'Pendidikan Kewarganegaraan', 'pkn', 'A'),
(3, 'Bahasa Indonesia', 'ind', 'A'),
(4, 'Bahasa Inggris', 'ing', 'A'),
(6, 'Matematika', 'mtkw', 'A'),
(7, 'Sejarah Indonesia', 'sji', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `nilai_id` int(11) NOT NULL,
  `nilai_siswa_nis` varchar(11) NOT NULL,
  `nilai_mapel_id` int(11) NOT NULL,
  `nilai_angka` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`nilai_id`, `nilai_siswa_nis`, `nilai_mapel_id`, `nilai_angka`) VALUES
(1, '12345', 1, 90),
(2, '12346', 1, 90),
(3, '12347', 1, 90),
(4, '12348', 1, 90),
(5, '12349', 1, 90),
(6, '12350', 1, 90),
(7, '12351', 1, 90),
(8, '12352', 1, 90),
(9, '12353', 1, 90),
(10, '12345', 3, 98),
(11, '12346', 3, 96),
(12, '12347', 3, 78),
(13, '12348', 3, 88),
(14, '12349', 3, 95),
(15, '12350', 3, 65),
(16, '12351', 3, 88),
(17, '12352', 3, 67),
(18, '12353', 3, 88),
(19, '12345', 2, 85),
(20, '12346', 2, 85),
(21, '12347', 2, 85),
(22, '12348', 2, 86),
(23, '12349', 2, 86),
(24, '12350', 2, 83),
(25, '12351', 2, 89),
(26, '12352', 2, 88),
(27, '12353', 2, 87);

-- --------------------------------------------------------

--
-- Table structure for table `nilai_jenis`
--

CREATE TABLE `nilai_jenis` (
  `nilai_jenis_id` int(2) NOT NULL,
  `nilai_jenis_nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nilai_jenis`
--

INSERT INTO `nilai_jenis` (`nilai_jenis_id`, `nilai_jenis_nama`) VALUES
(1, 'Nilai Ujian Sekolah'),
(2, 'Nilai Rata-rata Rapot');

-- --------------------------------------------------------

--
-- Table structure for table `pengaturan`
--

CREATE TABLE `pengaturan` (
  `pengaturan_id` int(1) NOT NULL,
  `pengaturan_sekolah` text NOT NULL,
  `pengaturan_alamat` text NOT NULL,
  `pengaturan_telp` varchar(100) NOT NULL,
  `pengaturan_fax` varchar(100) NOT NULL,
  `pengaturan_web` varchar(100) NOT NULL,
  `pengaturan_email` varchar(100) NOT NULL,
  `pengaturan_kab` varchar(100) NOT NULL,
  `pengaturan_pos` varchar(6) NOT NULL,
  `pengaturan_tgl_buka` date NOT NULL,
  `pengaturan_jam_buka` time NOT NULL,
  `pengaturan_password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pengaturan`
--

INSERT INTO `pengaturan` (`pengaturan_id`, `pengaturan_sekolah`, `pengaturan_alamat`, `pengaturan_telp`, `pengaturan_fax`, `pengaturan_web`, `pengaturan_email`, `pengaturan_kab`, `pengaturan_pos`, `pengaturan_tgl_buka`, `pengaturan_jam_buka`, `pengaturan_password`) VALUES
(1, 'SMA Negeri 1 Teladan Yogyakarta', 'Jalan Hos Cokroaminoto Nomor 10 ', '0274 513454', '0274 542604', 'http://sman1yogya.sch.id', 'humas@sman1yogya.sch.id', 'Yogyakarta', '55253', '0000-00-00', '00:00:00', '345345teladan');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `siswa_id` int(11) NOT NULL,
  `siswa_nis` varchar(6) NOT NULL,
  `siswa_nisn` varchar(15) NOT NULL,
  `siswa_nama` varchar(50) NOT NULL,
  `siswa_kelas` varchar(15) NOT NULL,
  `siswa_absen` varchar(3) NOT NULL,
  `siswa_tmp_lahir` varchar(100) NOT NULL,
  `siswa_tgl_lahir` date NOT NULL,
  `siswa_ortu` varchar(200) NOT NULL,
  `siswa_tahun_lulus` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`siswa_id`, `siswa_nis`, `siswa_nisn`, `siswa_nama`, `siswa_kelas`, `siswa_absen`, `siswa_tmp_lahir`, `siswa_tgl_lahir`, `siswa_ortu`, `siswa_tahun_lulus`) VALUES
(1, '12345', '123456789', 'wawan 1', 'mipa 1', '1', 'Yogya', '1992-05-12', 'Sarmidi 1', '2020'),
(2, '12346', '123456789', 'wawan 2', 'mipa 2', '2', 'Bantul', '1992-05-13', 'Sarmidi 2', '2020'),
(3, '12347', '123456789', 'wawan 3', 'mipa 3', '3', 'Sleman', '1992-05-14', 'Sarmidi 3', '2020'),
(4, '12348', '123456789', 'wawan 4', 'mipa 4', '4', 'Wates', '1992-05-15', 'Sarmidi 4', '2020'),
(5, '12349', '123456789', 'wawan 5', 'mipa 5', '5', 'Yogya', '1992-05-16', 'Sarmidi 5', '2020'),
(6, '12350', '123456789', 'wawan 6', 'mipa 6', '6', 'Bantul', '1992-05-17', 'Sarmidi 6', '2020'),
(7, '12351', '123456789', 'wawan 7', 'mipa 7', '7', 'Sleman', '1992-05-18', 'Sarmidi 7', '2020'),
(8, '12352', '123456789', 'wawan 8', 'mipa 8', '8', 'Wates', '1992-05-19', 'Sarmidi 8', '2020'),
(9, '12353', '123456789', 'wawan 9', 'mipa 9', '9', 'Yogya', '1992-05-20', 'Sarmidi 9', '2020');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mapel`
--
ALTER TABLE `mapel`
  ADD PRIMARY KEY (`mapel_id`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`nilai_id`);

--
-- Indexes for table `nilai_jenis`
--
ALTER TABLE `nilai_jenis`
  ADD PRIMARY KEY (`nilai_jenis_id`);

--
-- Indexes for table `pengaturan`
--
ALTER TABLE `pengaturan`
  ADD PRIMARY KEY (`pengaturan_id`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`siswa_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mapel`
--
ALTER TABLE `mapel`
  MODIFY `mapel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `nilai_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `nilai_jenis`
--
ALTER TABLE `nilai_jenis`
  MODIFY `nilai_jenis_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pengaturan`
--
ALTER TABLE `pengaturan`
  MODIFY `pengaturan_id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `siswa_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
