<!DOCTYPE html>
<html>
<head>
	<title>Download Format</title>
</head>
<body>

	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;
 
	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
 
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Format Nilai $mapel->mapel_nama.xls");
	?>
<h1>Format Upload Nilai</h1>
<p>Mapel : <?php echo $mapel->mapel_nama; ?> - Kelompok <?php echo $mapel->mapel_kelompok; ?><br>
Tahun : <?php echo date('Y'); ?></p>
<table border="1" cellpadding="3" cellspacing="0" width="100%">
	<tr bgcolor="grey">
		<th>No</th>
		<th>NIS</th>
		<th>Nama</th>
		<th>Kelas</th>
		<th>Id Mapel</th>
		<th>Nilai</th>
	</tr>
	<?php 
	$no = 1;
	foreach ($siswa as $value) {
	?>
	<tr>
		<td align="center"><?php echo $no; ?></td>
		<td align="center"><?php echo $value['siswa_nis'] ; ?></td>
		<td ><?php echo $value['siswa_nama'] ; ?></td>
		<td align="center"><?php echo $value['siswa_kelas'] ; ?></td>
		<td align="center"><?php echo $mapel->mapel_id; ?></td>
		<td></td>
	</tr>

<?php $no++; } ?>
</table>

</body>
</html>