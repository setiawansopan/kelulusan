<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa_con extends CI_Controller {

	public function index() {
        if(!$this->session->userdata('user')) {
            redirect(base_url('siswa_con/login'));
        }
        $this->load->model('siswa_mod');

        $nis = $this->session->user;
		$data['siswa'] = $this->siswa_mod->siswa_cek_nis($nis);
        $data['mapelA'] = $this->siswa_mod->siswa_nilai($nis, "A");
        $data['mapelB'] = $this->siswa_mod->siswa_nilai($nis, "B");
        $data['mapelC'] = $this->siswa_mod->siswa_nilai($nis, "C");
        $data['rata_rata'] = $this->siswa_mod->nilai_rata_rata($nis);
        $this->load->view('siswa/dashboard_siswa', $data);
	}

    public function cetak_surat() {
        if(!$this->session->userdata('user')) {
            redirect(base_url('siswa_con/login'));
        }
        $this->load->model('siswa_mod');

        $nis = $this->session->user;

        $data['pengaturan'] = $this->siswa_mod->pengaturan_ambil();
        $data['siswa'] = $this->siswa_mod->siswa_cek_nis($nis);
        $data['mapelA'] = $this->siswa_mod->siswa_nilai($nis, "A");
        $data['mapelB'] = $this->siswa_mod->siswa_nilai($nis, "B");
        $data['mapelC'] = $this->siswa_mod->siswa_nilai($nis, "C");
        $data['rata_rata'] = $this->siswa_mod->nilai_rata_rata($nis);
        $this->load->view('siswa/cetak_surat', $data);
    }

    public function save_pdf() {
        if(!$this->session->userdata('user')) {
            redirect(base_url('siswa_con/login'));
        }
        $this->load->model('siswa_mod');

        $this->load->library('Pdf');
        $this->load->view('siswa/cetak_surat');
    }

	public function login() {
        $this->load->model('siswa_mod');
        $data['pengaturan'] = $this->siswa_mod->pengaturan_ambil();
        $dateNow = new DateTime(date("d-m-Y H:i:s"));
        $dateBuka = new DateTime(date("d-m-Y H:i:s", strtotime($data['pengaturan']->pengaturan_tgl_buka." ".$data['pengaturan']->pengaturan_jam_buka)));

        if($dateNow <= $dateBuka) {
            $this->load->view('siswa/landing_page', $data);
        } else {
            $this->load->view('siswa/login', $data);
        }
    }

    public function auth($auth = null)
    {
        $this->load->model('siswa_mod');

        $username = $this->input->post('username'); 
        $password = $this->input->post('password'); 
        
        $pengaturan = $this->siswa_mod->pengaturan_ambil();
        $dateNow = new DateTime(date("d-m-Y H:i:s"));
        $dateBuka = new DateTime(date("d-m-Y H:i:s", strtotime($pengaturan->pengaturan_tgl_buka." ".$pengaturan->pengaturan_jam_buka)));

        if($dateNow <= $dateBuka) {
            $this->session->set_flashdata('error', 'Mohon maaf halaman belum dapat dibuka!');
            redirect($this->input->server('HTTP_REFERER', TRUE), 'location');
        }

        $tgl_lahir = substr($password,4,4)."-".substr($password,2,2)."-".substr($password,0,2);
        $login = $this->siswa_mod->login_cek($username, $tgl_lahir);

        if($login->num_rows() != 0) {
        	$user = $login->row()->siswa_nis;
            $user_nama = $login->row()->siswa_nama;
        	$this->session->set_userdata('user', $user);
            $this->session->set_userdata('user_nama', $user_nama);
        	redirect(base_url('siswa_con'));
        } else {
        	$this->session->set_flashdata('error', 'Username atau password yang anda masukkan tidak sesuai');
            redirect($this->input->server('HTTP_REFERER', TRUE), 'location');
        }        
    }

    public function logout()
    {
		$this->session->sess_destroy();
		redirect(base_url('siswa_con/login'));
    }
}
