<!DOCTYPE html>
<html>
<?php
$this->load->view('admin/header');
?>
<body>
<header>
<h1 align="center">SELAMAT DATANG DI DASHBOARD ADMIN KELULUSAN</h1>
<?php
$this->load->view('admin/navigasi');
?>
</header>

<br>
<div class="container">
<h4>Daftar Nilai Siswa Tahun <?php echo date('Y')?></h4>
<form action="<?php echo base_url('index.php/admin_con/nilai_upload'); ?>" method="POST" enctype="multipart/form-data">
	<table>
		<tr><td><input type="file" name="nilai_file" /></td></tr>
		<tr><td></td></tr>
		<tr><td><input type="submit"  class="btn btn-primary"  value="Upload Data" /></td></tr>
	</table>
</form>
</div>
<br>
<div class="container">
<h4>Download Format Upload Nilai</h4>
<form action="<?php echo base_url('index.php/admin_con/download_format'); ?>" method="POST">
	<table>
	<tr>
		<td>
			<select name="mapel_id">
				<option value="">Pilih..</option>
				<?php
				foreach ($mapel as  $value) {
				?>
				<option value="<?php echo $value['mapel_id'] ?>"> Kelompok <?php echo $value['mapel_kelompok'] ?> - <?php echo $value['mapel_nama'] ?> </option>
				<?php
				}

				?>
			</select>
		</td>
	</tr>
	<tr>
		<td><input type="submit" class="btn btn-success" name="download" value="Download"></td>
	</tr>
	</table>
</form>
</div>
</body>
</html>