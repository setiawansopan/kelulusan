<!DOCTYPE html>
<html>
<?php
$this->load->view('admin/header');
?>
<body>
<header>
<h1 align="center">SELAMAT DATANG DI DASHBOARD ADMIN KELULUSAN</h1>
<?php
$this->load->view('admin/navigasi');
?>
</header>
<div class="container">
	<br>
	<h4>Upload kelengkapan file </h4>
	<p>*) Maksimum ukuran gambar 2 Mb</p>
	<?php if($this->session->flashdata('success')) { ?>
        <div class="alert alert-success" role="alert" style="color:green"><?php echo $this->session->flashdata('success') ?></div>
    <?php } ?>
    <?php if($this->session->flashdata('error')) { ?>
        <div class="alert alert-danger" role="alert" style="color:red"><?php echo $this->session->flashdata('error') ?></div>
    <?php } ?>
	<form action="<?php echo base_url('index.php/admin_con/file_upload'); ?>" method="POST" enctype="multipart/form-data">
		<div class="form-group">
			<label for="Gambar Halaman Login">Gambar Halaman Login</label>
			<?php if($pengaturan->pengaturan_login_img !== NULL) { ?>
				<input type="hidden" name="gambar_login_old" value="<?php echo $pengaturan->pengaturan_login_img; ?>" /></td></tr>
				<br>
				<img width="300px" src="<?php echo base_url('images/upload/').$pengaturan->pengaturan_login_img; ?>">
				<br>
			<?php } ?>
			<input type="file" class="form-control-file" name="gambar_login"  /></td></tr>
		</div>
		<div class="form-group">
			<label for="Nama Sekolah Aksara Jawa">Nama Sekolah Aksara Jawa</label>
			<?php if($pengaturan->pengaturan_kop_img !== NULL) { ?>
				<input type="hidden" name="gambar_kop_jawa_old" value="<?php echo $pengaturan->pengaturan_kop_img; ?>" /></td></tr>
				<br>
				<img width="300px" src="<?php echo base_url('images/upload/').$pengaturan->pengaturan_kop_img; ?>">
				<br>
			<?php } ?>
			<input type="file" class="form-control-file" name="gambar_kop_jawa"  /></td></tr>
		</div>
		<div class="form-group">
			<label for="Tanda Tangan Kepala Sekolah">Tanda Tangan Kepala Sekolah</label>
			<?php if($pengaturan->pengaturan_ttd_img !== NULL) { ?>
				<input type="hidden" name="gambar_ttd_old" value="<?php echo $pengaturan->pengaturan_ttd_img; ?>" /></td></tr>
				<br>
				<img width="300px" src="<?php echo base_url('images/upload/').$pengaturan->pengaturan_ttd_img; ?>">
				<br>
			<?php } ?>
			<input type="file" class="form-control-file" name="gambar_ttd"  /></td></tr>
		</div>
		<input type="submit" value="Upload Data" class="btn btn-primary" /></td></tr>
	</form>
</div>
</body>
</html>